'use client'

import React from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  Button,
  Badge,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from '@shekara-dev/ui';
import { Zap, Info, BarChart3, Lightbulb, ExternalLink, Download } from 'lucide-react';

const GAPS_DATA = [
  {
    id: 1,
    impact: 'High',
    title: 'Vision Transformers + Few-Shot Learning',
    why: 'Both concepts appear frequently but have never been combined in research. This represents a novel research opportunity.',
    evidence: [
      { label: 'Vision Transformers', value: '12 papers' },
      { label: 'Few-Shot Learning', value: '8 papers' },
      { label: 'Combined', value: '0 papers', alert: true },
    ],
    question: 'Can vision transformers improve few-shot learning performance?',
  },
  {
    id: 2,
    impact: 'Medium',
    title: 'Self-Supervised Contrastive Learning in Medical Imaging',
    why: 'While contrastive learning is huge in general CV, its application to specific medical imaging benchmarks remains sparse.',
    evidence: [
      { label: 'Contrastive Learning', value: '15 papers' },
      { label: 'Medical Imaging', value: '22 papers' },
      { label: 'Intersection', value: '2 papers' },
    ],
    question: 'How does SimCLR scale to high-resolution MRI datasets?',
  },
  {
    id: 3,
    impact: 'High',
    title: 'RLHF for Low-Resource Languages',
    why: 'Reinforcement Learning from Human Feedback is dominant in English LLMs but significantly under-explored for low-resource linguistic contexts.',
    evidence: [
      { label: 'RLHF', value: '18 papers' },
      { label: 'Low-Resource NLP', value: '31 papers' },
      { label: 'Combined', value: '1 papers' },
    ],
    question: 'Can cross-lingual RLHF maintain safety while reducing annotation costs?',
  }
];

const GapAnalysis = () => {
  return (
    <div className="flex flex-col h-full bg-background">
      <div className="p-4 border-b sticky top-0 bg-background/95 backdrop-blur z-10 flex justify-between items-center">
        <div>
          <h2 className="text-lg font-bold tracking-tight">Research Gaps Identified</h2>
          <p className="text-xs text-muted-foreground">Found based on co-occurrence analysis</p>
        </div>
        <Select defaultValue="all">
          <SelectTrigger className="w-[130px] h-8 text-xs">
            <SelectValue placeholder="All Impacts" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Impacts</SelectItem>
            <SelectItem value="high">High Impact</SelectItem>
            <SelectItem value="medium">Medium Impact</SelectItem>
            <SelectItem value="low">Low Impact</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-20 md:pb-4">
        {GAPS_DATA.map((gap) => (
          <Card key={gap.id} className="overflow-hidden border-muted/60 shadow-sm hover:shadow-md transition-shadow">
            <CardHeader className="p-4 pb-2">
              <div className="flex justify-between items-start mb-1">
                <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Gap #{gap.id}</span>
                <Badge variant={gap.impact === 'High' ? 'destructive' : 'secondary'} className="text-[10px] px-1.5 py-0 h-4 uppercase font-bold">
                  <Zap className="w-2.5 h-2.5 mr-1 fill-current" />
                  {gap.impact}
                </Badge>
              </div>
              <CardTitle className="text-base leading-tight">{gap.title}</CardTitle>
            </CardHeader>
            
            <CardContent className="p-4 pt-2 space-y-4">
              <div className="space-y-1.5">
                <div className="flex items-center gap-1.5 text-primary text-[11px] font-bold uppercase tracking-wider">
                  <Info className="w-3 h-3" />
                  Why This Matters
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {gap.why}
                </p>
              </div>

              <div className="bg-muted/30 rounded-lg p-3 space-y-2">
                <div className="flex items-center gap-1.5 text-muted-foreground text-[11px] font-bold uppercase tracking-wider">
                  <BarChart3 className="w-3 h-3" />
                  Evidence
                </div>
                <div className="space-y-1">
                  {gap.evidence.map((item, idx) => (
                    <div key={idx} className="flex justify-between text-xs">
                      <span className="text-muted-foreground">• {item.label}</span>
                      <span className={item.alert ? "font-bold text-destructive flex items-center" : "font-medium"}>
                        {item.value}
                        {item.alert && <Zap className="w-2.5 h-2.5 ml-1 fill-current" />}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center gap-1.5 text-primary text-[11px] font-bold uppercase tracking-wider">
                  <Lightbulb className="w-3 h-3" />
                  Suggested Research Question
                </div>
                <p className="text-sm font-medium italic border-l-2 border-primary/30 pl-3 py-1">
                  "{gap.question}"
                </p>
              </div>
            </CardContent>

            <CardFooter className="p-4 pt-0 flex gap-2">
              <Button variant="outline" size="sm" className="flex-1 h-8 text-xs">
                <ExternalLink className="w-3 h-3 mr-2" />
                View in Graph
              </Button>
              <Button variant="outline" size="sm" className="flex-1 h-8 text-xs">
                <Download className="w-3 h-3 mr-2" />
                Export Gap
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default GapAnalysis;
