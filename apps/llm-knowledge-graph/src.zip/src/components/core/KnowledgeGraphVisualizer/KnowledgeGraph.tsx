'use client'

import React, { useState, useCallback, useRef, useEffect } from 'react';
import ForceGraph2D from 'react-force-graph-2d';
import { GraphData } from '../../../lib/types/graph';
import { defaultGraphData } from './lib/model';
import { Search, Maximize2, ZoomIn, ZoomOut, Filter, Layers } from 'lucide-react';
import { useSidebar, Button, Input, Badge } from '@shekara-dev/ui';

interface KnowledgeGraphVisualizerProps {
  graphData?: GraphData;
}

const KnowledgeGraphVisualizer: React.FC<KnowledgeGraphVisualizerProps> = ({ graphData: initialGraphData }) => {
  const graphRef = useRef<any>();
  const [searchQuery, setSearchQuery] = useState('');
  const [highlightNodes, setHighlightNodes] = useState(new Set());
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [dimensions, setDimensions] = useState({ width: 800, height: 600 });
  const graphData = initialGraphData || defaultGraphData;
  const { open, isMobile } = useSidebar();

  const nodeColors = {
    Concept: '#3b82f6', // Blue
    Method: '#10b981', // Green
    Technology: '#10b981', // Green
    Finding: '#f59e0b', // Amber
    Metric: '#ef4444', // Red
    ResearchGap: '#ec4899', // Pink
    Dataset: '#8b5cf6', // Violet
    default: '#94a3b8'
  };

  const legendItems = [
    { label: 'Concept', color: '#3b82f6' },
    { label: 'Method', color: '#10b981' },
    { label: 'Dataset', color: '#8b5cf6' },
    { label: 'Finding', color: '#f59e0b' },
  ];

  // Handle window resize and sidebar state
  useEffect(() => {
    const updateDimensions = () => {
      const mainElement = document.querySelector('main');
      if (mainElement) {
        const rect = mainElement.getBoundingClientRect();
        // On mobile, the graph usually takes full width
        // On desktop, it depends on whether the sidebar is open
        setDimensions({
          width: rect.width,
          height: rect.height
        });
      }
    };

    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    // Also update when sidebar state changes
    const timer = setTimeout(updateDimensions, 310); // Match sidebar transition duration

    return () => {
      window.removeEventListener('resize', updateDimensions);
      clearTimeout(timer);
    };
  }, [open, isMobile]);

  // Transform data for react-force-graph
  const transformedData = {
    nodes: graphData.nodes.map(node => ({
      id: node.id,
      name: node.label || node.id,
      type: node.type,
      color: nodeColors[node.type] || nodeColors.default,
      val: 10
    })),
    links: graphData.relationships.map(rel => ({
      source: rel.source,
      target: rel.target,
      type: rel.type
    }))
  };

  // Filter nodes based on search and type
  const filteredData = {
    nodes: transformedData.nodes.filter(node => {
      const matchesSearch = searchQuery === '' ||
        node.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesType = selectedType === null || node.type === selectedType;
      return matchesSearch && matchesType;
    }),
    links: transformedData.links.filter(link => {
      const sourceNode = transformedData.nodes.find(n => n.id === (typeof link.source === 'object' ? link.source.id : link.source));
      const targetNode = transformedData.nodes.find(n => n.id === (typeof link.target === 'object' ? link.target.id : link.target));
      
      if (!sourceNode || !targetNode) return false;

      const matchesSearch = searchQuery === '' ||
        sourceNode.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        targetNode.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesType = selectedType === null ||
        sourceNode.type === selectedType ||
        targetNode.type === selectedType;
      return matchesSearch && matchesType;
    })
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);

    if (query === '') {
      setHighlightNodes(new Set());
      return;
    }

    const matching = new Set(
      transformedData.nodes
        .filter(node => node.name.toLowerCase().includes(query.toLowerCase()))
        .map(node => node.id)
    );
    setHighlightNodes(matching);
  };

  const handleZoomIn = () => graphRef.current?.zoom(graphRef.current.zoom() * 1.2, 300);
  const handleZoomOut = () => graphRef.current?.zoom(graphRef.current.zoom() / 1.2, 300);
  const handleFit = () => graphRef.current?.zoomToFit(400, 50);

  return (
    <div className="relative w-full h-full bg-slate-50/50 overflow-hidden">
      {/* Search and Controls Overlay */}
      <div className="absolute top-4 left-4 right-4 z-10 flex flex-col md:flex-row gap-2 pointer-events-none">
        <div className="relative flex-1 max-w-md pointer-events-auto">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="Search nodes..."
            value={searchQuery}
            onChange={handleSearch}
            className="pl-9 bg-background/80 backdrop-blur shadow-sm border-muted/60 h-10"
          />
        </div>
        
        <div className="flex gap-2 pointer-events-auto">
          <Button variant="secondary" size="sm" className="bg-background/80 backdrop-blur shadow-sm border-muted/60 h-10">
            <Filter className="w-4 h-4 mr-2" />
            Filter by type
          </Button>
          
          <div className="hidden md:flex gap-1 bg-background/80 backdrop-blur p-1 rounded-md shadow-sm border border-muted/60">
            <Button variant="ghost" size="icon" onClick={handleZoomIn} className="h-8 w-8"><ZoomIn className="w-4 h-4" /></Button>
            <Button variant="ghost" size="icon" onClick={handleZoomOut} className="h-8 w-8"><ZoomOut className="w-4 h-4" /></Button>
            <Button variant="ghost" size="icon" onClick={handleFit} className="h-8 w-8"><Maximize2 className="w-4 h-4" /></Button>
          </div>
        </div>
      </div>

      {/* Legend Overlay */}
      <div className="absolute bottom-4 left-4 z-10 pointer-events-auto">
        <div className="bg-background/80 backdrop-blur p-3 rounded-xl shadow-sm border border-muted/60 min-w-[140px]">
          <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-2 flex items-center gap-1.5">
            <Layers className="w-3 h-3" />
            Legend
          </div>
          <div className="space-y-1.5">
            {legendItems.map((item) => (
              <div
                key={item.label}
                className={`flex items-center gap-2 cursor-pointer hover:bg-accent/50 px-1.5 py-1 rounded-md transition-colors ${selectedType === item.label ? 'bg-accent' : ''}`}
                onClick={() => setSelectedType(selectedType === item.label ? null : item.label)}
              >
                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-xs font-medium text-foreground/80">{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Graph Canvas */}
      <ForceGraph2D
        ref={graphRef}
        graphData={filteredData}
        width={dimensions.width}
        height={dimensions.height}
        backgroundColor="transparent"
        nodeRelSize={6}
        nodeVal={node => highlightNodes.has(node.id) ? 14 : 10}
        linkDirectionalArrowLength={4}
        linkDirectionalArrowRelPos={1}
        linkWidth={link => {
          const sId = typeof link.source === 'object' ? link.source.id : link.source;
          const tId = typeof link.target === 'object' ? link.target.id : link.target;
          return highlightNodes.has(sId) || highlightNodes.has(tId) ? 2.5 : 1;
        }}
        linkColor={() => '#cbd5e1'}
        linkCurvature={0.1}
        nodeCanvasObject={(node: any, ctx, globalScale) => {
          const label = node.name;
          const fontSize = 12 / globalScale;
          const isHighlighted = highlightNodes.has(node.id) || (selectedType && node.type === selectedType);
          
          // Node Circle
          ctx.beginPath();
          ctx.arc(node.x, node.y, isHighlighted ? 7 : 5, 0, 2 * Math.PI);
          ctx.fillStyle = node.color;
          ctx.fill();
          
          if (isHighlighted) {
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 2 / globalScale;
            ctx.stroke();
          }

          // Label
          ctx.font = `${isHighlighted ? '600' : '400'} ${fontSize}px Inter, system-ui, sans-serif`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'top';
          
          const textWidth = ctx.measureText(label).width;
          const bckgDimensions = [textWidth + 4, fontSize + 2];
          
          ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
          ctx.fillRect(node.x - bckgDimensions[0] / 2, node.y + 8, bckgDimensions[0], bckgDimensions[1]);
          
          ctx.fillStyle = isHighlighted ? '#0f172a' : '#64748b';
          ctx.fillText(label, node.x, node.y + 9);
        }}
      />
    </div>
  );
};

export default KnowledgeGraphVisualizer;
